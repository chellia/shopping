package com.atego.dorsnextapi.xml.impl;

/**
 * represents a XMLAttribute
 * @author uharneit
 *
 */
public class XMLAttribute {
	private String name_;
	private String value_;

	/**
	 * creates an XMLAttribute
	 * 
	 * @param name
	 *            name of Attribute
	 * @param value
	 *            value of Attribute
	 */
	public XMLAttribute(String name, String value) {
		this.name_ = name;
		this.value_ = value;
	}

	/**
	 * @return the name
	 */
	public final String getName() {
		return name_;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public final void setName(String name) {
		this.name_ = name;
	}

	/**
	 * @return the value
	 */
	public final String getValue() {
		return value_;
	}

	/**
	 * @param value
	 *            the value to set
	 */
	public final void setValue(String value) {
		this.value_ = value;
	}

	public void printAttribtue() {
		System.out.println("Name: " + this.name_);
		System.out.println("value: " + this.value_);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public final int hashCode() {
		return super.hashCode();
	}

	/**
	 * compares an Object with this XMLAttribute
	 * 
	 * @param o
	 *            the Object to be compared with this
	 * @return true if o is an XMLAttribute and has the same name
	 */
	@Override
	public final boolean equals(Object o) {
		if (o instanceof XMLAttribute) {
			XMLAttribute otherXMLAttribute = (XMLAttribute) o;
			return otherXMLAttribute.getName().equals(this.getName());
		}
		return false;
	}

}
