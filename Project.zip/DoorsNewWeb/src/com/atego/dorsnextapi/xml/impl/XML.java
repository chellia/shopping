package com.atego.dorsnextapi.xml.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

/**
 * represents a XML-file
 * @author uharneit
 *
 */
public class XML {
	private HashMap<String, ArrayList<XMLElement>> elements_;
	private XMLElement thisAsElement;

	/**
	 * @return the thisAsElement
	 */
	public final XMLElement getThisAsElement() {
		return thisAsElement;
	}

	/**
	 * creates the Object
	 */
	public XML() {
		this.elements_ = new HashMap<String, ArrayList<XMLElement>>();
		thisAsElement = new XMLElement("");
		thisAsElement.setChildelements(elements_);
	}

	public void printXML() {
		System.out.println("Elements:");
		Set<Entry<String, ArrayList<XMLElement>>> entries = this.elements_
				.entrySet();
		Entry<String, ArrayList<XMLElement>>[] e = new Entry[elements_.size()];
		for (Entry<String, ArrayList<XMLElement>> entry : entries.toArray(e)) {
			System.out.println("elements with name " + entry.getKey());
			ArrayList<XMLElement> elementslist = entry.getValue();
			for (XMLElement element : elementslist) {
				element.printElement();
			}
		}
	}

	/**
	 * @return the elements
	 */
	public final HashMap<String, ArrayList<XMLElement>> getElements() {
		return elements_;
	}

	/**
	 * @param elements
	 *            the elements to set
	 */
	public final void setElements(
			HashMap<String, ArrayList<XMLElement>> elements) {
		this.elements_ = elements;
	}

	/**
	 * adds an element to the map of elements
	 * 
	 * @param element
	 *            a xml-elewment or tag
	 */
	public final void addElement(XMLElement element) {
		ArrayList<XMLElement> elementlist = this.elements_.get(element
				.getName());
		if (elementlist == null) {
			elementlist = new ArrayList<XMLElement>();
		}
		elementlist.add(element);
		this.elements_.put(element.getName(), elementlist);
	}

	/**
	 * returns an xmlelement with a given name
	 * 
	 * @param name
	 *            of xmlelement
	 * @return xmlelement
	 */
	public final ArrayList<XMLElement> findElementsByName(String name) {
		return this.elements_.get(name);
	}

}
