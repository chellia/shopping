package com.atego.dorsnextapi.xml.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

/**
 * represents an XMLElement
 * @author uharneit
 *
 */
public class XMLElement {
	private String name_;
	private HashMap<String, ArrayList<XMLElement>> childelements_;
	private HashMap<String, XMLAttribute> attributes_;
	private XMLElement parentelement_;
	private String text_;

	/**
	 * creates a new XMLElement
	 * 
	 * @param name
	 *            of the XMLElement
	 */
	public XMLElement(String name) {
		this.name_ = name;
		this.childelements_ = new HashMap<String, ArrayList<XMLElement>>();
		this.attributes_ = new HashMap<String, XMLAttribute>();
		this.text_ = "";
	}

	/**
	 * returns an XMLAttribute by it's name
	 * 
	 * @param name
	 *            name of attribute
	 * @return XMLAttribute with the given name
	 */
	public final XMLAttribute getAttributeByName(String name) {
		return attributes_.get(name);
	}

	/**
	 * returns the value of an XMLAttribute with the given name
	 * 
	 * @param name
	 *            of XMLAttribute
	 * @return value of XMLAttribute with given name
	 */
	public final String getAttributeValue(String name) {
		XMLAttribute attribute = this.getAttributeByName(name);
		if (attribute != null) {
			return attribute.getValue();
		}
		return null;

	}

	public void printElement() {
		if (this.parentelement_ == null) {
			System.out.println("Name = " + this.name_);
		} else {
			System.out.println("Name = " + this.name_ + " parent = "
					+ this.parentelement_.getName());
		}

		System.out.println("Text = " + this.text_);
		System.out.println("Attributes:");
		Set<Entry<String, XMLAttribute>> attrentries = this.attributes_
				.entrySet();
		Entry<String, XMLAttribute>[] ea = new Entry[attributes_.size()];
		for (Entry<String, XMLAttribute> entry : attrentries.toArray(ea)) {
			XMLAttribute attribute = entry.getValue();
			attribute.printAttribtue();
		}
		System.out.println("Elements:");
		Set<Entry<String, ArrayList<XMLElement>>> entries = this.childelements_
				.entrySet();
		Entry<String, ArrayList<XMLElement>>[] e = new Entry[childelements_
				.size()];
		for (Entry<String, ArrayList<XMLElement>> entry : entries.toArray(e)) {
			System.out.println("elements with name " + entry.getKey());
			ArrayList<XMLElement> elementslist = entry.getValue();
			for (XMLElement element : elementslist) {
				element.printElement();
			}
		}
		/*
		 * for (XMLElement child:this.getChildelements()) {
		 * System.out.println("Element:"); child.printElement();
		 * System.out.println(
		 * "------------------------------------------------------------------------"
		 * ); }
		 */
	}

	/**
	 * gets a childelement by the name of the childelement
	 * 
	 * @param name
	 *            of childelement
	 * @return the childelement with given name
	 */
	public final ArrayList<XMLElement> findElementsByName(String name) {
		return this.childelements_.get(name);
	}

	/**
	 * adds a childelement to the map of childelements
	 * 
	 * @param childelement
	 *            the childelement
	 */
	public final void addChildElement(XMLElement childelement) {
		ArrayList<XMLElement> elementlist = this.childelements_
				.get(childelement.getName());
		if (elementlist == null) {
			elementlist = new ArrayList<XMLElement>();
		}
		elementlist.add(childelement);
		this.childelements_.put(childelement.getName(), elementlist);
	}

	/**
	 * adds a XMLAttribute to the attributes
	 * 
	 * @param attribute
	 *            the XMLAttribute
	 */
	public final void addAttribute(XMLAttribute attribute) {
		this.attributes_.put(attribute.getName(), attribute);
	}

	/**
	 * 
	 * @return the name
	 */
	public final String getName() {
		return name_;
	}

	/**
	 * 
	 * @param name
	 *            new name
	 */
	public final void setName(String name) {
		this.name_ = name;
	}

	/**
	 * 
	 * @return the childelements
	 */
	public final HashMap<String, ArrayList<XMLElement>> getChildelements() {
		return childelements_;
	}

	/**
	 * sets childelements
	 * 
	 * @param childelements
	 *            the new childelements
	 */
	public final void setChildelements(
			HashMap<String, ArrayList<XMLElement>> childelements) {
		this.childelements_ = childelements;
	}

	/**
	 * 
	 * @return the attribtues
	 */
	public final HashMap<String, XMLAttribute> getAttributes() {
		return attributes_;
	}

	/**
	 * 
	 * @param attributes
	 *            the new attributes
	 */
	public final void setAttributes(HashMap<String, XMLAttribute> attributes) {
		this.attributes_ = attributes;
	}

	/**
	 * gets the parentelmeent
	 * 
	 * @return the parentelement
	 */
	public final XMLElement getParentelement() {
		return parentelement_;
	}

	/**
	 * sets the parentelement
	 * 
	 * @param parentelement
	 *            the new parentelement
	 */
	public final void setParentelement(XMLElement parentelement) {
		this.parentelement_ = parentelement;
	}

	/**
	 * 
	 * @return the text between elements
	 */
	public final String getText() {
		return text_;
	}

	/**
	 * 
	 * @param text
	 *            between elements
	 */
	public final void setText(String text) {
		this.text_ = text;
	}

}
