package com.atego.dorsnextapi.xml.impl;


import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Logger;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

//import com.atego.exerpt.utils.general.LoggerUtils;

/**
 * this class parses a XML-file
 * @author uharneit
 *
 */
public class XMLParser extends DefaultHandler {

	private static final Logger logger_ = Logger.getLogger("LegacyParser");

	private XML xml;

	private XMLElement parentelement = null;
	private XMLElement currentelement = null;
	private ArrayList<XMLElement> openelements;

	/**
	 * creates an XMLParser-object and parses the given file
	 * 
	 * @param filename
	 *            name including path of xml-file
	 */
	public XMLParser(String filename) {

		openelements = new ArrayList<XMLElement>();
		this.xml = new XML();
		this.parse(filename);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.xml.sax.helpers.DefaultHandler#endElement(java.lang.String,
	 * java.lang.String, java.lang.String)
	 */
	@Override
	public final void endElement(String uri, String localName, String qname) {
		this.currentelement = null;
		int lastelement = this.openelements.size() - 1;
		this.openelements.remove(lastelement);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.xml.sax.helpers.DefaultHandler#startElement(java.lang.String,
	 * java.lang.String, java.lang.String, org.xml.sax.Attributes)
	 */
	@Override
	public final void startElement(String uri, String localName, String qname,
			Attributes attributes) {

		this.currentelement = new XMLElement(qname);

		for (int i = 0; i < attributes.getLength(); i++) {
			String attrname = attributes.getLocalName(i);
			XMLAttribute attribute = new XMLAttribute(attrname,
					attributes.getValue(i));
			currentelement.addAttribute(attribute);
		}
		int lastelement = this.openelements.size() - 1;
		if (lastelement > -1) {
			parentelement = this.openelements.get(lastelement);
		} else {
			parentelement = null;
		}
		if (parentelement != null) {
			parentelement.addChildElement(currentelement);
			currentelement.setParentelement(parentelement);
		} else {
			xml.addElement(this.currentelement);
		}
		openelements.add(this.currentelement);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.xml.sax.helpers.DefaultHandler#characters(char[], int, int)
	 */
	@Override
	public final void characters(char[] chars, int start, int length) {
		if (this.currentelement != null) {
			String text = String.valueOf(chars);
			int last = start + length;
			text = text.substring(start, last);
			currentelement.setText(text);
		}
	}

	/**
	 * parses the xml-file
	 * 
	 * @param file
	 *            the xml-file
	 */
	private void parse(String file) {
		try {
			FileInputStream in = new FileInputStream(file);
			SAXParserFactory factory = SAXParserFactory.newInstance();
			SAXParser parser = factory.newSAXParser();
			parser.parse(in, this);
			in.close();
		} catch (org.xml.sax.SAXParseException e) {
			// LoggerUtils.logException(logger_,
			// "Failed to parse legacy roundtrip!", e);
		} catch (ParserConfigurationException e) {
			// LoggerUtils.logException(logger_,
			// "Failed to parse legacy roundtrip!", e);
		} catch (SAXException e) {
			// LoggerUtils.logException(logger_,
			// "Failed to parse legacy roundtrip!", e);
		} catch (IOException e) {
			// LoggerUtils.logException(logger_,
			// "Failed to parse legacy roundtrip!", e);
		}
	}

	/**
	 * 
	 * @return the resulting XML-Object
	 */
	public final XML getXml() {
		return xml;
	}

	public static void main(String[] args) {
		// TransformXMI test2old = new
		// TransformXMI("C:\\Users\\uharneit\\workspaceXMI\\Test-Case-16\\valid-canonical.xmi",false);
		XMLParser test2new = new XMLParser("C:\\Rational\\Next_M.xml");
		XML xml = test2new.getXml();
		xml.printXML();
		// System.out.println(test2old.getOriginalxml().equals(test2new.getNewxml()));
		// System.out.println(test2new.getOriginalxml().equals(test2old.getNewxml()));

	}

}
