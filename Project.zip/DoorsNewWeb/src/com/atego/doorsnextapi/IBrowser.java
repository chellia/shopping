package com.atego.doorsnextapi;

import java.util.ArrayList;



public interface IBrowser {
	public void shutdown();
	public String[] listOfProjects();
	public ArrayList<IDNResource> listOfModules(String projectarea);
	public String getModuleContent(String projectname, String moduleid) throws Exception ;

}
