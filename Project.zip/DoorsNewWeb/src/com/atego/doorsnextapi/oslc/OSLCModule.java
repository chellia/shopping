/**
 * 
 */
package com.atego.doorsnextapi.oslc;

import com.atego.doorsnextapi.IDNResource;

/**
 * @author uharneit
 *
 */
public class OSLCModule implements IDNResource {
	
	private String id;
	private String name;
	

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	
	public OSLCModule(String id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	@Override
	public String getID() {
		// TODO Auto-generated method stub
		return id;
	}
	@Override
	public void setID(String id) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void setName(String id) {
		// TODO Auto-generated method stub
		
	}
	

}
