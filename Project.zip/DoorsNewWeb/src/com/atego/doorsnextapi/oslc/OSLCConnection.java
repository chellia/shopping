package com.atego.doorsnextapi.oslc;

import com.atego.doorsnextapi.IConnection;

public class OSLCConnection implements IConnection {
	/*private String server = "https://uk-che-devm-043:9443/rm";		// Set the Public URI of your RRC server
	private String JTS_Server = "https://uk-che-devm-043:9443/jts"; //Set the public URI of your JTS server
	
	private String login = "tester";									// Set the user login 
	private String password = "Password1";								// Set the associated password*/
	private String server;		// Set the Public URI of your RRC server
	private String port;
	private String login;									// Set the user login 
	private String password;								// Set the associated password
	
	public static IConnection getConnection(String servername, String port, String login, String password)
	{
		return new OSLCConnection(servername, port, login, password);
	}

	private OSLCConnection(String servername, String port, String login, String password)
	{
		//this.server=servername+":"+port+"/rm";
		//this.JTS_Server=servername+":"+port+"/jts";
		this.server=servername;
		this.port=port;
		this.login=login;
		this.password=password;
	}
	
	
	
	public String getLogin() {
		return login;
	}


	public String getServer() {
		return server;
	}


	public String getPassword() {
		return password;
	}


	/**
	 * @return the port
	 */
	public String getPort() {
		return port;
	}
	
}
