/**
 * 
 */
package com.atego.doorsnextapi.oslc;

import com.atego.doorsnextapi.IBrowser;
import com.atego.doorsnextapi.IConnection;
import com.atego.doorsnextapi.IFactory;

/**
 * @author uharneit
 *
 */
public class OSLCFactory implements IFactory {
	
	private OSLCBrowser browser;
	private OSLCConnection connection;
	
    private OSLCFactory()
    {
    	
    }
	/* (non-Javadoc)
	 * @see com.atego.doorsnextapi.IFactory#createConnection(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public IConnection createConnection(String servername, String port, String login, String password) {
		// TODO Auto-generated method stub
		connection =  (OSLCConnection) OSLCConnection.getConnection(servername, port, login, password);
		return connection;
	}

	/* (non-Javadoc)
	 * @see com.atego.doorsnextapi.IFactory#createBrowser(com.atego.doorsnextapi.IConnection)
	 */
	@Override
	public IBrowser createBrowser() {
		// TODO Auto-generated method stub
		browser =  (OSLCBrowser) OSLCBrowser.getBrowser(connection);
		return browser;
	}


	public static IFactory createFactory() {
		// TODO Auto-generated method stub
		return new OSLCFactory();
	}
	/**
	 * @return the browser
	 */
	public IBrowser getBrowser() {
		return browser;
	}
	/**
	 * @return the connection
	 */
	public IConnection getConnection() {
		return connection;
	}

}
