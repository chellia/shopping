package com.atego.doorsnextapi.oslc;

import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.util.ArrayList;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.auth.InvalidCredentialsException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.HttpResponseException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.atego.doorsnextapi.IBrowser;
import com.atego.doorsnextapi.IConnection;
import com.atego.doorsnextapi.IDNResource;
import com.atego.doorsnextapi.utils.DNFileUtils;
import com.atego.dorsnextapi.xml.impl.XML;
import com.atego.dorsnextapi.xml.impl.XMLElement;
import com.atego.dorsnextapi.xml.impl.XMLParser;

//import net.jazz.oslc.utils.HttpUtils;
//import net.jazz.oslc.utils.NamespaceContextMap;

public class OSLCBrowser implements IBrowser {
	private OSLCConnection connection;
	private DefaultHttpClient httpclient;
	private String server;		// Set the Public URI of your RRC server
	private String JTS_Server; //Set the public URI of your JTS server
	
	public static IBrowser getBrowser(IConnection connection)
	{
		return new OSLCBrowser(connection);
	}

	private OSLCBrowser(IConnection connection) {
		super();
		this.connection = (OSLCConnection) connection;
		this.server=connection.getServer()+":"+connection.getPort()+"/rm";
		this.JTS_Server=connection.getServer()+":"+connection.getPort()+"/jts";
		httpclient = new DefaultHttpClient();
		//HttpUtils.setupLazySSLSupport(httpclient);
	}
	
	public void shutdown()
	{
		httpclient.getConnectionManager().shutdown();
	}
	
	public String[] listOfProjects()
	{
		
		String rootServices = this.server + "/rootservices";
		String catalogXPath = "/rdf:Description/oslc_rm:rmServiceProviders/@rdf:resource";
		String serviceProviderTitleXPath = "//oslc:ServiceProvider/dcterms:title";
		
	/*	System.out.println(">> Example03: Print out the content of the Service Providers catalog");
		System.out.println("	- Root Services URI: "+rootServices);
		System.out.println("	- Service Providers catalog XPath expression: "+catalogXPath);
		System.out.println("	- Service Provider title XPath expression: "+serviceProviderTitleXPath);
		System.out.println("	- Login: "+this.connection.getLogin());
		System.out.println("	- Password: "+this.connection.getPassword());*/

		// Setup the HttClient
		//DefaultHttpClient httpclient = new DefaultHttpClient();
		//HttpUtils.setupLazySSLSupport(httpclient);
		
		// Setup the rootServices request
		HttpGet rootServiceDoc = new HttpGet(rootServices);
		rootServiceDoc.addHeader("Accept", "application/rdf+xml");
		rootServiceDoc.addHeader("OSLC-Core-Version", "2.0");
		String[] projects = null;
		try {
			// Request the Root Services document
			/*HttpResponse rootServicesResponse = HttpUtils.sendGetForSecureDocument(
													this.server, rootServiceDoc,this.connection.getLogin(), this.connection.getPassword(), httpclient,this.JTS_Server);
			*/
			HttpResponse rootServicesResponse = null;
			if (rootServicesResponse.getStatusLine().getStatusCode() == 200) {
	    		// Define the XPath evaluation environment
				XPathFactory factory = XPathFactory.newInstance();
				XPath xpath = factory.newXPath();
				/*xpath.setNamespaceContext(
						new NamespaceContextMap(new String[]
								{	"rdf", "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
									"oslc_rm","http://open-services.net/xmlns/rm/1.0/"}));*/
				xpath.setNamespaceContext(null);
				// Parse the response body to retrieve the catalog URI
				InputSource source = new InputSource(rootServicesResponse.getEntity().getContent());
				Node attribute = (Node) (xpath.evaluate(catalogXPath, source, XPathConstants.NODE));
				String serviceProvidersCatalog = attribute.getTextContent();
				rootServicesResponse.getEntity().consumeContent();

				// Setup the catalog request
				HttpGet catalogDoc = new HttpGet(serviceProvidersCatalog);
				catalogDoc.addHeader("Accept", "application/xml");
				catalogDoc.addHeader("OSLC-Core-Version", "2.0");
				
				// Access to the Service Providers catalog
				/*HttpResponse catalogResponse = HttpUtils.sendGetForSecureDocument(
															this.server, catalogDoc, this.connection.getLogin(), this.connection.getPassword(), httpclient,this.JTS_Server);
				*/
				HttpResponse catalogResponse = null;
				
				if (catalogResponse.getStatusLine().getStatusCode() == 200) {
		    		// Define the XPath evaluation environment
					XPath xpath2 = factory.newXPath();
					/*xpath2.setNamespaceContext(
							new NamespaceContextMap(new String[]
									{	"oslc", "http://open-services.net/ns/core#",
										"dcterms","http://purl.org/dc/terms/"}));*/
					xpath2.setNamespaceContext(null);

					
					// Parse the response body to retrieve the Service Provider
					source = new InputSource(catalogResponse.getEntity().getContent());
					NodeList titleNodes = (NodeList) (xpath2.evaluate(serviceProviderTitleXPath, source, XPathConstants.NODESET));
					
					// Print out the title of each Service Provider
					int length = titleNodes.getLength();
					projects = new String[length];
					//System.out.println(">> Project Areas:");
					for (int i = 0; i < length; i++) {
						//System.out.println(">> \t - "+ titleNodes.item(i).getTextContent());
						projects[i] = titleNodes.item(i).getTextContent();
					}
				}
			}
			rootServicesResponse.getEntity().consumeContent();
		} catch (ClientProtocolException e) {
			e.printStackTrace();
			projects = null;
		} catch (IOException e) {
			e.printStackTrace();
		
		} catch (XPathExpressionException e) {
			e.printStackTrace();
		
		}  finally {
			// Shutdown the HTTP connection
		//	httpclient.getConnectionManager().shutdown();
		}
		return projects;
	}
	
	//helper method for getting xpath
		// added nav for defect https://jazz.net/jazz03/web/projects/Requirements%20Management#action=com.ibm.team.workitem.viewWorkItem&id=114458
		private XPath getXpathNamespace(){
			XPathFactory factory = XPathFactory.newInstance();
			XPath xpath = factory.newXPath();
			/*xpath.setNamespaceContext(
					new NamespaceContextMap(new String[]
							{	"rdf", "http://www.w3.org/1999/02/22-rdf-syntax-ns#",
								"oslc_rm","http://open-services.net/xmlns/rm/1.0/",
								"oslc", "http://open-services.net/ns/core#",
								"rm", "http://www.ibm.com/xmlns/rdm/rdf/",
								"dcterms", "http://purl.org/dc/terms/",
								"nav", "http://jazz.net/ns/rm/navigation#"}));*/
			xpath.setNamespaceContext(null);
			return xpath;
		}
	
	/**
	 * Retrieve the URI of a specific Service Provider
	 * 
	 * @param catalogURI	- The catalog to look into
	 * @param paName		- The Service Provider we are looking for
	 */
	private String getServiceProvider(String catalogURI, String paName) throws InvalidCredentialsException, IOException, XPathExpressionException {
		//System.out.println(catalogURI);
		HttpGet query = new HttpGet(catalogURI);
		query.addHeader("Accept", "application/rdf+xml");
		query.addHeader("OSLC-Core-Version", "2.0");
		
		// Access to the Service Providers catalog
		/*HttpResponse response = HttpUtils.sendGetForSecureDocument(
												this.server, query, this.connection.getLogin(), this.connection.getPassword(), httpclient, this.JTS_Server);
	*/
		HttpResponse response = null;

		if (response.getStatusLine().getStatusCode() != 200) {
			response.getEntity().consumeContent();
			throw new HttpResponseException(response.getStatusLine().getStatusCode(), response.getStatusLine().getReasonPhrase());
		}
		// Define the XPath evaluation environment
		XPath xpath = getXpathNamespace();
		//String serviceProviderXPath = "//oslc_disc:ServiceProvider/[dcterms:title=\"" + paName + "\"]/../oslc_disc:services/@rdf:resource";
		String serviceProviderXPath = "//oslc:ServiceProvider[dcterms:title=\""+paName+"\"]/@rdf:about";


		// Retrieve the designated Service Provider
		InputSource source = new InputSource(response.getEntity().getContent());
		Node paNode = (Node)(xpath.evaluate(serviceProviderXPath, source, XPathConstants.NODE));
		if (paNode == null) {
			response.getEntity().consumeContent();
			throw new RuntimeException("Unknown Project Area: "+paName);
		}
		response.getEntity().consumeContent();
		return paNode.getTextContent();
	}
	
	/**
	 * Retrieve the Service Provider Catalog URI from the Root Services Document
	 */
	private String getServiceProviderCatalog() throws InvalidCredentialsException, IOException, XPathExpressionException {
		String rootServices = this.server+ "/rootservices";
		HttpGet query = new HttpGet(rootServices);
		query.addHeader("Accept", "application/rdf+xml");
		query.addHeader("OSLC-Core-Version", "2.0");
		
		// Request the Root Services document
		/*HttpResponse response = HttpUtils.sendGetForSecureDocument(
				this.server, query, this.connection.getLogin(), this.connection.getPassword(), httpclient, this.JTS_Server);*/
		
		HttpResponse response = null;
		
		if (response.getStatusLine().getStatusCode() != 200) {
			response.getEntity().consumeContent();
			throw new HttpResponseException(response.getStatusLine().getStatusCode(), response.getStatusLine().getReasonPhrase());
		}
		// Define the XPath evaluation environment
		XPath xpath = getXpathNamespace();
		String catalogXPath = "/rdf:Description/oslc_rm:rmServiceProviders/@rdf:resource";

		// Parse the response body to retrieve the catalog URI
		InputSource source = new InputSource(response.getEntity().getContent());
		Node attribute = (Node) (xpath.evaluate(catalogXPath, source, XPathConstants.NODE));
		String serviceProvidersCatalog = attribute.getTextContent();
		
		
		response.getEntity().consumeContent();
		
		return serviceProvidersCatalog;
	}
	
	private String getQueryCapability(String serviceProviderURI) throws Exception {
		HttpGet serviceProvider = new HttpGet(serviceProviderURI);
		serviceProvider.addHeader("Accept", "application/xml");
		serviceProvider.addHeader("OSLC-Core-Version", "2.0");
		/*HttpResponse response = HttpUtils.sendGetForSecureDocument(
				this.server, serviceProvider, this.connection.getLogin(), this.connection.getPassword(), httpclient, this.JTS_Server);*/
		HttpResponse response = null;
		InputSource source = new InputSource(response.getEntity().getContent());
		
		// Define the XPath evaluation environment
		XPath xpath = getXpathNamespace();
		
		//Resource Type
		String resourceType = "http://open-services.net/ns/rm#Requirement";
		
		String requirementQueryUrl ="//oslc:QueryCapability/oslc:resourceType[@rdf:resource=\"" + resourceType +"\"]/../oslc:queryBase/@rdf:resource";
		Node evaluate = (Node)xpath.evaluate(requirementQueryUrl, source, XPathConstants.NODE);
		String query = evaluate.getTextContent();
		//System.out.println("Query URI->> " + query);
		response.getEntity().consumeContent();
					
		return query;
	}
	
	
	private ArrayList<IDNResource> getModulesFromfile(File input)
	{
		ArrayList<IDNResource> modules = new ArrayList<IDNResource>();
		XMLParser parser= new XMLParser(input.getAbsolutePath());
		XML xml = parser.getXml();
		XMLElement root = xml.findElementsByName("rdf:RDF").get(0);
		XMLElement responseinfo = root.findElementsByName("oslc:ResponseInfo").get(0);
		ArrayList<XMLElement> members = responseinfo.findElementsByName("rdfs:member");
		for (XMLElement member:members)
		{
			ArrayList<XMLElement> requirementcollections = member.findElementsByName("oslc_rm:RequirementCollection");
			if ((requirementcollections != null) && (requirementcollections.size()>0))
			{
				for (XMLElement requirementcollection:requirementcollections)
				{
					String about = requirementcollection.getAttributeValue("rdf:about");
					String[] parts = about.split("/");
					String id = parts[parts.length-1];
					XMLElement title = requirementcollection.findElementsByName("dcterms:title").get(0);
					String name=title.getText();
					OSLCModule module = new OSLCModule(id,name);
					modules.add(module);
				}
			}
		}
	    input.delete();
	    return modules;
	}
	
	public ArrayList<IDNResource> listOfModules(String projectarea)
	{
		ArrayList<IDNResource> modules = null;
		

		// Setup the HttClient
		
		String catalog;
		try {
			catalog = getServiceProviderCatalog();
			//System.out.println("catalog = "+catalog);
			String serviceprovider = getServiceProvider(catalog , projectarea) ;
			//System.out.println("serviceprovider = "+serviceprovider);
			// Step (3) : Find the query capability element in the service provider document
			String queryCapabilityURI = getQueryCapability(serviceprovider);
						
						// Step (4) : Perform query operation
			File resultfile = performQuery(queryCapabilityURI);
			modules = this.getModulesFromfile(resultfile);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
		return modules;
	}
	
	private  File performQuery(String queryCapabilityURI) throws Exception
	{
		// Query by Identifier
		// for this example, pick an id that you know exists in the project that you are using
	//	String identifier = "779";
		String oslcSearchByIdentifierQuery = queryCapabilityURI + "&oslc.prefix=" + URLEncoder.encode("dcterms=<http://purl.org/dc/terms/>", "UTF8") +
		                          "&oslc.select=" + URLEncoder.encode("dcterms:title", "UTF8");/* + 
		                           "&oslc.where=" + URLEncoder.encode("dcterms:identifier=" + identifier, "UTF8");*/
		String[] lhsrhs = oslcSearchByIdentifierQuery.split("\\?");
		File responsefile = null;
		// OR
		
		// Query by Full Text Search using string "Donor"
		/*String oslcSearchForVisionQuery = queryCapabilityURI +
		                           "&oslc.prefix=" + URLEncoder.encode("dcterms=<http://purl.org/dc/terms/>", "UTF8") + "," +
		                                             URLEncoder.encode("types=<http://www.ibm.com/xmlns/rdm/types/>", "UTF8") + "," +
                                   "&oslc.select=" + URLEncoder.encode("dcterms:title", "UTF8") + "," +
                                                     URLEncoder.encode("types:PrimaryText", "UTF8") +
                                   "&oslc.searchTerms=" + URLEncoder.encode("\"Vision\"", "UTF8");
		String[] lhsrhs = oslcSearchForVisionQuery.split("\\?");                                   
                                   */

		
		String url = lhsrhs[0];
		String body = lhsrhs[1];
		
	//	System.out.println("Search Query string: "+body);
			
		HttpPost post = new HttpPost(url);
		post.addHeader("Accept", "application/rdf+xml");
		post.addHeader("OSLC-Core-Version", "2.0");
		post.addHeader("Content-type", "application/x-www-form-urlencoded");
		
		HttpEntity entity = new ByteArrayEntity(body.getBytes("UTF8"));
		post.setEntity(entity);
		HttpResponse postResponse = null;//add the package here//HttpUtils.sendPostForSecureDocument(this.server, post, this.connection.getLogin(), this.connection.getPassword(), httpclient, 200);
		if (postResponse.getStatusLine().getStatusCode() == 200) {
			InputStream responseStream = postResponse.getEntity().getContent();
			byte[] responseBytes = toBytes(responseStream);
			String responseString = new String(responseBytes, "UTF8");
			//System.out.println(responseString);
			responsefile = DNFileUtils.createXMLfile(responseString,"OSLC","result");
			
		}else{
		//	System.out.println(postResponse.getStatusLine());
		}	
		return responsefile;		
	}
	
	
	
	private static byte[] toBytes(InputStream stream) throws IOException {
		ByteArrayOutputStream fileBytesOutputStream = new ByteArrayOutputStream();
		try {
			int read;
			byte[] next = new byte[1024];
			while ((read = stream.read(next)) != -1) {
				fileBytesOutputStream.write(next, 0, read);
			}
		} finally {
			stream.close();
			fileBytesOutputStream.close();
		}
		return fileBytesOutputStream.toByteArray();
	}
	
	public static void main(String[] args)
	{
		File file;
		try {
			file = File.createTempFile("oslc", "result");
			System.out.println(file.getAbsolutePath());
			File xmlfile = new File(file.getAbsolutePath().replaceAll("\\.", "")+".xml");
			System.out.println(xmlfile.getAbsolutePath());
			file.renameTo(xmlfile);
			System.out.println(file.getAbsolutePath());
			file.delete();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public String getModuleContent(String projectname, String moduleid) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}

