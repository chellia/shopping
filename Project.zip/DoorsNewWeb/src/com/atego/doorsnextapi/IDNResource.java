package com.atego.doorsnextapi;

public interface IDNResource {
	
	public String getID();
	
	public void setID(String id);
	
	public String getName();
	
	public void setName(String id);

}
