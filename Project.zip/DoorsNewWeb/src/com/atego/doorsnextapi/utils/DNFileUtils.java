package com.atego.doorsnextapi.utils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class DNFileUtils {
	
	public static File createXMLfile(String content, String prefix, String suffix) throws IOException
	{
		File file = File.createTempFile(prefix, suffix);
		File xmlfile = new File(file.getAbsolutePath().replaceAll("\\.", "")+".xml");
		//String fileName = "C:\\Rational\\Next.xml";
		BufferedWriter bw = null;
		FileWriter fw = null;
		try {
			fw = new FileWriter(xmlfile);
			bw = new BufferedWriter(fw);
			bw.write(content);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (bw != null)
					bw.close();
				if (fw != null)
					fw.close();
			} catch (IOException ex) {
				ex.printStackTrace();

			}

		}
		file.delete();
		return xmlfile;
	}

}
