/**
 * 
 */
package com.atego.doorsnextapi;

public interface IFactory {
	
	
	
	IConnection createConnection(String servername, String port, String login, String password);
	
	IBrowser createBrowser();
	
	/**
	 * @return the browser
	 */
	public IBrowser getBrowser();
	/**
	 * @return the connection
	 */
	public IConnection getConnection();
}
