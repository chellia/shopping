package com.atego.doorsnextapi;

public interface IConnection {
	public String getLogin() ;
	public String getServer();
	public String getPassword();
	public String getPort();

}
