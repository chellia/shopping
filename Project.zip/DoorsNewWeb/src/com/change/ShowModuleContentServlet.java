package com.change;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.atego.doorsnextapi.IBrowser;
import com.atego.doorsnextapi.IDNResource;


@WebServlet("/showModuleContent")
public class ShowModuleContentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowModuleContentServlet() {
        super();
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	String id = request.getParameter("id");
    	String name = request.getParameter("name");
    	IBrowser browserApi = ServletUtils.connectBrowserFromSession(request.getSession());    	
    	String moduleContent = null;
		try {
			moduleContent = browserApi.getModuleContent(name,id);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	request.setAttribute("moduleContent", moduleContent);
		getServletContext().getRequestDispatcher("/jsp/moduleContent.jsp").forward(request, response);
	}
}
