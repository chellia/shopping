package com.change;

import javax.servlet.http.HttpSession;

import com.atego.doorsnextapi.IBrowser;
import com.atego.doorsnextapi.IFactory;
import com.atego.doorsnextapi.oslc.OSLCFactory;

public class ServletUtils {

	public static IBrowser connectBrowserFromSession(HttpSession session){
		IFactory factory = OSLCFactory.createFactory();
		factory.createConnection(session.getAttribute("servername").toString(), session.getAttribute("port").toString(), session.getAttribute("login").toString(), session.getAttribute("password").toString());
		IBrowser browseDoorsApi = factory.createBrowser();
		return browseDoorsApi;
	}
}
