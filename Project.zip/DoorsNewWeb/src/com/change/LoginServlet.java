package com.change;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.atego.doorsnextapi.IBrowser;
import com.atego.doorsnextapi.IFactory;
import com.atego.doorsnextapi.oslc.OSLCFactory;


@WebServlet("/connect")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String port = request.getParameter("port");
		String servername = request.getParameter("server");
		String login = request.getParameter("uname");
		String password = request.getParameter("password");
		
		if (login.equals("tester") && password.equals("Password1") && port.equals("9443") && servername.equals("https://uk-che-devm-043")) {
			HttpSession session = request.getSession();
			String[] modulesFromSession = (String[]) session.getAttribute("projects");
			
			if(modulesFromSession == null ){				
				IFactory factory = OSLCFactory.createFactory();
				factory.createConnection(servername, port, login, password);
				IBrowser browseDoorsApi = factory.createBrowser();
				String[] projects = browseDoorsApi.listOfProjects();	
				addToSession(session,port,servername,login,password,projects);
			}
			getServletContext().getRequestDispatcher("/jsp/projects.jsp").forward(request, response);
		} 
		else {
			response.sendRedirect("error.jsp");
		}
	}

	private void addToSession(HttpSession httpSession,String port, String servername, String login, String password, String[] projects) {
		httpSession.setAttribute("port", port);
		httpSession.setAttribute("servername", servername);
		httpSession.setAttribute("login", login);
		httpSession.setAttribute("password", password);
		httpSession.setAttribute("projects", projects);
	}
}